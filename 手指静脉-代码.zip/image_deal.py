import cv2 as cv
import numpy as np
import math
import sys
import matplotlib as plt


img = cv.imread("roi.jpg", 0)
I_min, I_max = cv.minMaxLoc(img)[:2]
O_min, O_max = 0, 255
# 计算a和b的值
a = float(O_max - O_min) / (I_max - I_min)
b = O_min - a * I_min
out = a * img + b
out = out.astype(np.uint8)
cv.imshow("img", img)
cv.imshow("out", out)
cv.waitKey(0)
cv.destroyAllWindows()
cv.imwrite("roi_strong.jpg", out)

